<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.5" name="door" tilewidth="15" tileheight="15" tilecount="1" columns="1">
 <image source="door.png" width="15" height="15"/>
</tileset>
