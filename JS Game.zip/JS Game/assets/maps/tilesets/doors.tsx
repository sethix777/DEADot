<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.5" name="doors" tilewidth="15" tileheight="15" tilecount="4" columns="4">
 <image source="doors.png" width="60" height="15"/>
</tileset>
